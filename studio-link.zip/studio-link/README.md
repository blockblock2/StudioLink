# Studio Link

Lets Claude (on claude.ai, in any browser or the app) read and edit the place you have open in Roblox Studio.

```
Claude ──custom connector──▶ Cloudflare Worker (relay) ◀──long-poll── Studio Link plugin (inside Studio)
```

Nothing extra runs on your Mac. The relay lives on Cloudflare, and the plugin runs inside Studio.

## 1. Deploy the relay (one time)

```bash
cd worker
npx wrangler deploy
```

Wrangler prints a URL such as `https://studio-link.<your-subdomain>.workers.dev`. Opening it should show "Studio Link relay is running."

The relay uses one Durable Object, which works on the free Workers plan.

## 2. Install the plugin

1. In Studio, open the **Plugins** tab and click **Plugins Folder**.
2. Drop `plugin/StudioLink.rbxmx` into that folder.
3. Restart Studio, or reopen your place. A **Studio Link** button appears on the Plugins tab.

## 3. Connect

1. Click **Studio Link** to open the panel.
2. Paste your relay URL into box 1 and press **Connect**.
3. Studio asks whether the plugin may make HTTP requests to your workers.dev domain. Click **Allow**.
4. Copy the **Claude connector URL** from box 2.
5. In Claude, go to **Settings → Connectors → Add custom connector**. Name it "Roblox Studio" and paste the URL.
6. Enable the connector in a chat, then ask Claude something like "what's in my Workspace?"

After the first setup, the plugin reconnects automatically whenever Studio opens.

## What Claude can do

| Tool | What it does |
|---|---|
| `studio_status` | Checks whether Studio is connected and which place is open |
| `get_tree` | Shows the instance hierarchy |
| `get_properties` / `set_properties` | Reads or changes properties, attributes and tags |
| `create_instance` / `clone_instance` / `delete_instance` | Builds or removes parts, models, GUIs and scripts |
| `read_script` / `write_script` / `edit_script` | Works with scripts |
| `search` | Finds things by name, class, or text inside scripts |
| `get_selection` / `set_selection` | Reads what you've selected, or selects things to show you |
| `get_output` | Reads the Output window (prints, warnings, errors) |
| `run_luau` | Runs any Luau code in edit mode |

Every change shows up in Studio's undo history as "Claude: …", so **Cmd+Z** undoes it.

## Security

The connector URL contains a long random secret. Anyone who has it can edit whatever place you have open while Studio is connected, so don't share it. If it leaks, click **Make a new secret URL** in the panel and update the connector in Claude.

## Troubleshooting

- **Red "HTTP blocked" status:** go to Plugins → Manage Plugins → Studio Link and allow HTTP access to your workers.dev domain.
- **Claude says Studio isn't connected:** the panel should show a green dot. Press Connect if it doesn't.
- **A tool timed out:** the command may still have run. Ask Claude to check before it retries.
